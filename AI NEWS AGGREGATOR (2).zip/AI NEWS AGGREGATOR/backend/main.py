from fastapi import FastAPI, Body
from fastapi.middleware.cors import CORSMiddleware
import feedparser
import re

from database import engine, SessionLocal
from models import Base, NewsItem, Favorite, BroadcastLog

from newspaper import Article
from pydantic import BaseModel

from sumy.parsers.plaintext import PlaintextParser
from sumy.nlp.tokenizers import Tokenizer
from sumy.summarizers.lsa import LsaSummarizer

app = FastAPI()
Base.metadata.create_all(bind=engine)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ✅ 20 RSS SOURCES (TESTED)
RSS_FEEDS = {
    "TechCrunch AI": "https://techcrunch.com/tag/artificial-intelligence/feed/",
    "VentureBeat AI": "https://venturebeat.com/category/ai/feed/",
    "MIT Tech": "https://www.technologyreview.com/feed/",
    "Wired": "https://www.wired.com/feed/category/ai/latest/rss",
    "The Verge": "https://www.theverge.com/rss/index.xml",

    "ArXiv AI": "http://export.arxiv.org/rss/cs.AI",
    "ArXiv ML": "http://export.arxiv.org/rss/cs.LG",
    "ArXiv NLP": "http://export.arxiv.org/rss/cs.CL",

    "Hacker News": "https://hnrss.org/newest?q=AI",
    "Reddit AI": "https://www.reddit.com/r/artificial/.rss",

    "Towards Data Science": "https://towardsdatascience.com/feed",
    "Analytics Vidhya": "https://www.analyticsvidhya.com/blog/feed/",
    "KDnuggets": "https://www.kdnuggets.com/feed",

    "InfoQ": "https://www.infoq.com/ai-ml-data-eng/rss/",
    "MarkTechPost": "https://www.marktechpost.com/feed/",
    "AI Trends": "https://www.aitrends.com/feed/",
    "ML Mastery": "https://machinelearningmastery.com/feed/",
    "Product Hunt": "https://www.producthunt.com/feed",

    "VentureBeat": "https://feeds.feedburner.com/venturebeat/SZYF",
    "MIT News AI": "https://news.mit.edu/rss/topic/artificial-intelligence2"
}

@app.get("/")
def home():
    return {"message": "Backend Running"}

# ✅ FETCH NEWS WITH DEBUG
@app.get("/fetch-news")
def fetch_news():
    db = SessionLocal()
    seen_titles = set()

    for source, url in RSS_FEEDS.items():
        print(f"🔄 Fetching: {source}")

        try:
            feed = feedparser.parse(url)

            if not feed.entries:
                print(f"❌ No data from {source}")
                continue

            for entry in feed.entries:
                title_clean = entry.title.strip().lower()[:80]

                if title_clean in seen_titles:
                    continue
                seen_titles.add(title_clean)

                summary = entry.get("summary", "")

                news = NewsItem(
                    title=entry.title,
                    summary=summary,
                    source=source,
                    url=entry.link,
                    published_at=entry.get("published", ""),
                    is_duplicate=False
                )

                db.add(news)

        except Exception as e:
            print(f"❌ Error {source}: {e}")

    db.commit()
    db.close()

    return {"message": "Fetched successfully"}

# ✅ GET NEWS
@app.get("/news")
def get_news():
    db = SessionLocal()
    data = db.query(NewsItem).order_by(NewsItem.id.desc()).limit(100).all()
    db.close()
    return data

# ✅ FAVORITES
class FavoriteRequest(BaseModel):
    news_id: int

@app.post("/favorite")
def add_favorite(request: FavoriteRequest):
    db = SessionLocal()

    existing = db.query(Favorite).filter(Favorite.news_id == request.news_id).first()
    if existing:
        db.close()
        return {"message": "Already added"}

    fav = Favorite(news_id=request.news_id)
    db.add(fav)
    db.commit()
    db.close()

    return {"message": "Added"}

@app.get("/favorites")
def get_favorites():
    db = SessionLocal()
    favs = db.query(Favorite).all()

    result = []
    for f in favs:
        news = db.query(NewsItem).filter(NewsItem.id == f.news_id).first()
        if news:
            result.append(news)

    db.close()
    return result

@app.delete("/favorite/{news_id}")
def remove_favorite(news_id: int):
    db = SessionLocal()
    fav = db.query(Favorite).filter(Favorite.news_id == news_id).first()

    if fav:
        db.delete(fav)
        db.commit()

    db.close()
    return {"message": "Removed"}

# ✅ BROADCAST MOCK
@app.post("/broadcast")
def broadcast(news_id: int = Body(...), platform: str = Body(...)):
    db = SessionLocal()

    log = BroadcastLog(news_id=news_id, platform=platform, status="SUCCESS")
    db.add(log)
    db.commit()
    db.close()

    return {"message": f"Shared to {platform}"}

# ✅ REFRESH
@app.get("/refresh")
def refresh():
    return fetch_news()

# ✅ SUMMARIZATION FIXED
class TextRequest(BaseModel):
    text: str

@app.post("/summarize")
def summarize(request: TextRequest):
    try:
        full_text = ""

        try:
            article = Article(request.text)
            article.download()
            article.parse()
            full_text = article.text
        except:
            pass

        if not full_text:
            clean = re.sub(r'<.*?>', '', request.text)
            full_text = clean

        parser = PlaintextParser.from_string(full_text, Tokenizer("english"))
        summarizer = LsaSummarizer()

        summary = summarizer(parser.document, 3)
        result = " ".join([str(s) for s in summary])

        return {"summary": result if result else full_text[:150]}

    except Exception as e:
        return {"error": str(e)}

# ✅ CAPTION
class TitleRequest(BaseModel):
    title: str

@app.post("/generate-caption")
def caption(req: TitleRequest):
    return {
        "caption": f"🚀 {req.title}\n\n#AI #Tech #Innovation"
    }

# ✅ DEBUG SOURCES
@app.get("/debug/sources")
def debug_sources():
    db = SessionLocal()
    sources = db.query(NewsItem.source).all()
    db.close()

    unique = list(set([s[0] for s in sources]))

    return {"total_sources": len(unique), "sources": unique}