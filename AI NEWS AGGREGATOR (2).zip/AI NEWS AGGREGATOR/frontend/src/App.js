import React, { useEffect, useState } from "react";
import axios from "axios";

const API = "http://127.0.0.1:8000";

function App() {
  const [news, setNews] = useState([]);
  const [favorites, setFavorites] = useState([]);
  const [view, setView] = useState("news");
  const [loading, setLoading] = useState(false);

  // ✅ NEW: backend source tracking
  const [sourcesData, setSourcesData] = useState([]);
  const [totalSources, setTotalSources] = useState(0);

  useEffect(() => {
    loadInitial();
  }, []);

  const loadInitial = async () => {
    setLoading(true);
    await axios.get(`${API}/fetch-news`);
    await fetchNews();
    await fetchFavorites();
    await fetchSources(); // 🔥 IMPORTANT
    setLoading(false);
  };

  const fetchNews = async () => {
    const res = await axios.get(`${API}/news`);
    setNews(res.data);
  };

  const fetchFavorites = async () => {
    const res = await axios.get(`${API}/favorites`);
    setFavorites(res.data);
  };

  // ✅ FETCH REAL SOURCES
  const fetchSources = async () => {
    const res = await axios.get(`${API}/debug/sources`);
    setSourcesData(res.data.sources);
    setTotalSources(res.data.total_sources);
  };

  const refreshNews = async () => {
    setLoading(true);
    await axios.get(`${API}/refresh`);
    await fetchNews();
    await fetchSources(); // 🔥 keep updated
    setLoading(false);
    alert("News refreshed!");
  };

  const addFavorite = async (id) => {
    await axios.post(`${API}/favorite`, { news_id: id });
    fetchFavorites();
  };

  const removeFavorite = async (id) => {
    await axios.delete(`${API}/favorite/${id}`);
    fetchFavorites();
  };

  const summarizeNews = async (item) => {
    const res = await axios.post(`${API}/summarize`, {
      text: item.url + " " + (item.summary || item.title),
    });
    alert(res.data.summary);
  };

  const caption = async (title) => {
    const res = await axios.post(`${API}/generate-caption`, { title });
    alert(res.data.caption);
  };

  const broadcast = async (id, platform) => {
    await axios.post(`${API}/broadcast`, {
      news_id: id,
      platform,
    });
    alert(`Shared to ${platform}`);
  };

  const data = view === "news" ? news : favorites;

  const totalNews = news.length;
  const totalFav = favorites.length;

  return (
    <div style={styles.container}>
      <h1 style={styles.title}>🚀 AI News Dashboard</h1>

      {/* 📊 DASHBOARD */}
      <div style={styles.stats}>
        <div>📰 News: {totalNews}</div>
        <div>⭐ Favorites: {totalFav}</div>
        <div>🌐 Sources: {totalSources}</div>
      </div>

      {/* 🌐 SOURCE BADGES */}
      <div style={styles.sources}>
        {sourcesData.map((src, i) => (
          <span key={i} style={styles.badge}>
            {src}
          </span>
        ))}
      </div>

      {/* NAV */}
      <div style={styles.nav}>
        <button onClick={() => setView("news")} style={styles.btn}>
          News
        </button>
        <button onClick={() => setView("favorites")} style={styles.btn}>
          Favorites
        </button>
        <button onClick={refreshNews} style={styles.refresh}>
          🔄 Refresh
        </button>
      </div>

      {loading && <p style={{ textAlign: "center" }}>Loading...</p>}

      {/* 📰 NEWS GRID */}
      <div style={styles.grid}>
        {data.map((item) => (
          <div key={item.id} style={styles.card}>
            <h3>{item.title}</h3>

            <span style={styles.source}>{item.source}</span>
            <p style={styles.date}>{item.published_at}</p>

            <a href={item.url} target="_blank" rel="noreferrer">
              🔗 Read Article
            </a>

            <div style={styles.actions}>
              {view === "news" && (
                <button onClick={() => addFavorite(item.id)}>⭐</button>
              )}
              {view === "favorites" && (
                <button onClick={() => removeFavorite(item.id)}>❌</button>
              )}

              <button onClick={() => summarizeNews(item)}>🧠</button>
              <button onClick={() => caption(item.title)}>✍️</button>

              <button onClick={() => broadcast(item.id, "Email")}>📧</button>
              <button onClick={() => broadcast(item.id, "LinkedIn")}>💼</button>
              <button onClick={() => broadcast(item.id, "WhatsApp")}>💬</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;

//////////////////////////////////////////////////
// 🎨 STYLES
//////////////////////////////////////////////////

const styles = {
  container: {
    padding: "30px",
    fontFamily: "Segoe UI",
    background: "#f0f2f5",
  },
  title: {
    textAlign: "center",
  },
  stats: {
    display: "flex",
    justifyContent: "space-around",
    margin: "20px 0",
    fontWeight: "bold",
  },
  sources: {
    textAlign: "center",
    marginBottom: "15px",
  },
  badge: {
    background: "#007bff",
    color: "white",
    padding: "5px 10px",
    borderRadius: "10px",
    margin: "5px",
    display: "inline-block",
  },
  nav: {
    textAlign: "center",
    marginBottom: "20px",
  },
  btn: {
    margin: "5px",
    padding: "10px 15px",
    borderRadius: "8px",
    border: "none",
    background: "#333",
    color: "white",
    cursor: "pointer",
  },
  refresh: {
    margin: "5px",
    padding: "10px 15px",
    borderRadius: "8px",
    border: "none",
    background: "green",
    color: "white",
    cursor: "pointer",
  },
  grid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))",
    gap: "20px",
  },
  card: {
    background: "white",
    padding: "20px",
    borderRadius: "12px",
    boxShadow: "0 4px 10px rgba(0,0,0,0.1)",
  },
  source: {
    background: "#eee",
    padding: "3px 8px",
    borderRadius: "5px",
    fontSize: "12px",
  },
  date: {
    fontSize: "12px",
    color: "gray",
  },
  actions: {
    marginTop: "10px",
    display: "flex",
    gap: "10px",
    flexWrap: "wrap",
  },
};